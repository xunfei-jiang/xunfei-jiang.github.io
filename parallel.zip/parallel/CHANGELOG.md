### 1.3.5 - 26/5/2017

Changes:

- Applied changes mentioned in https://themes.trac.wordpress.org/ticket/41732#comment:14


### 1.3.4 - 13/5/2017

Changes:

- Fixed incorrect link in /inc/welcome/theme-welcome.php
- Edited text in /inc/options.php
- Removed .lite and .dark css selectors in section files
- Updated the demo content import files
- Removed Jetpack as recommended plugin


### 1.3.3 - 08/5/2017

Changes:

- Edited text in /inc/options.php
- Edited text in /inc/welcome/theme-welcome.php


### 1.3.2 - 13/3/2017

Changes:

- Changed readme.txt (adding missing copyright for third party script)


### 1.3.1 - 11/3/2017

Changes:

- Fixed misc. issues
- Changed top navigation script
- Added demo content files


### 1.3.0 - 04/3/2017

Changes:

* INITIAL RELEASE *